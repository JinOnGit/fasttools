#!/usr/bin/env python3
#pip install python-nmap

import nmap
import os
from colorama import init, Fore,  Back,  Style
from lib.menu import checkVersion, clear, menu
from lib.loading import thread_loading

checkVersion()
thread_loading()

############################################################################################

#les differents headers a ré-utiliser

header = """                                                                \n
        ######################################################\n
        #             Welcome To Jin's                       #\n
        #                                                    #\n
        #                   Fast                             #\n
        #                                                    #\n
        #             Multitools V1.0a                       #\n
        ######################################################\n"""

headerNmap = """                                                             \n
        ######################################################\n
        #             Welcome To Jin's                       #\n
        #                                                    #\n
        #                   Fast                             #\n
        #                                                    #\n
        #              Network Scanner                       #\n
        ######################################################\n"""

headerVuln = """                                                             \n
        ######################################################\n
        #             Welcome To Jin's                       #\n
        #                                                    #\n
        #                   Fast                             #\n
        #                                                    #\n
        #            Vulnerability Scanner                   #\n
        ######################################################\n"""


############################################################################################

#definitions de thermes

sc = nmap.PortScanner()

############################################################################################

clear()
print(header)

def main():
    n = input("1- Network Scanner\n2- Vulnerability Scanner\n3- Exploit Vulnerability\n4- OSINT Toolsn\n\n\nOther Options :      e: exit script  h: Open Help Page\n\nPlease Chose an option while typing a number :  ")
    
    if n == '1':
        clear()
        nmap()

    if n == '2':
        clear()
        vuln()

    if n == '3':
        clear()
        os.system('msfconsole')

    if n == '4':
        clear()
        os.system('python3 osint.py')

    if n == 'e':
        clear()
        print("bye !")

def nmap():
    print(headerNmap)
    ip = input("\nPlease Enter the IP adress: ")
    sc.scan(ip , '1-1023')
    print(sc.scaninfo())
    print(sc[ip]['tcp'].keys())

def vulnEx():
    print(headerVuln)
    ip = input("\nPlease Enter the IP adress: ")
    print(os.system('nmap -sV --script=vulscan.nse ' +ip))

if __name__ == "__main__":
    main()