#!/usr/bin/env python3
#pip install python-nmap

import nmap
import os
from colorama import init, Fore,  Back,  Style
from lib.menu import checkVersion, clear, menu
from lib.loading import thread_loading

checkVersion()
thread_loading()

############################################################################################

#les differents headers a ré-utiliser

header = """                                                                \n
        ######################################################\n
        #             Welcome To Jin's                       #\n
        #                                                    #\n
        #                   Fast                             #\n
        #                                                    #\n
        #             Multitools V1.0a                       #\n
        ######################################################\n"""

headerNmap = """                                                             \n
        ######################################################\n
        #             Welcome To Jin's                       #\n
        #                                                    #\n
        #                   Fast                             #\n
        #                                                    #\n
        #              Network Scanner                       #\n
        ######################################################\n"""

headerVuln = """                                                             \n
        ######################################################\n
        #             Welcome To Jin's                       #\n
        #                                                    #\n
        #                   Fast                             #\n
        #                                                    #\n
        #            Vulnerability Scanner                   #\n
        ######################################################\n"""

headerExploit = """                                                             \n
        ######################################################\n
        #             Welcome To Jin's                       #\n
        #                                                    #\n
        #                   Fast                             #\n
        #                                                    #\n
        #             Exploitation Tools                     #\n
        ######################################################\n"""

###########################################################################################

#page help

hlp = """                                                             \n
        ######################################################\n
        #                                                    #\n
        #                   HELP PAGE                        #\n
        #                                                    #\n
        ######################################################\n

        Network Scanner (1) :  Un Scanner d'ip qu vous revelera les specificité sur les port 1-1024 d'une ip.


        Vulnerability Scanner (2): Un scanner utilisant les fonction "nmap" pour reveler les services vulnerable d'une ip.


        Exploitation(3): cette option permet une liaison avec la console metasploit afin de pouvoir exploité les vulnerabilitées presente.


        OSINT Tools (4) [NEW!]: Cette Options vous permet d'acceder a un panel d'outils faisant une synteses des outils disponible mais en les ameliorant pour votre confort


      ******************************************************************************************

                                  ######################
                                  #                    #
                                  #    Patch Note      #
                                  #                    #
                                  ######################

            OSINT tools dans sa premiere version ajouté, comprend les fonctionalitées de LittleBrother Revisiter


      ******************************************************************************************

                                  ######################
                                  #                    #
                                  #       SOON !       #
                                  #                    #
                                  ######################


            - Ajout de fonctionalité a "OSINT Tools" notament sur la recherche telephonique

            - Modification de l'interface de "OSINT Tools"

            - Ajout d'un menue Malware permettant de gagner du temps sur la creation de payloads/shells etc...

        """


############################################################################################

#definitions de thermes

sc = nmap.PortScanner()

############################################################################################

clear()
print(header)

def main():
    n = input("1- Network Scanner\n2- Vulnerability Scanner\n3- Exploitation\n4- OSINT Tools\n\n\nOther Options :      e: exit script  h: Open Help Page\n\nPlease Chose an option while typing a number :  ")

    if n == '1':
        clear()
        nmap()

    if n == '2':
        clear()
        vulnEx()

    if n == '3':
        clear()
        exploit()

    if n == '4':
        clear()
        toolindev()

    if n == 'e':
        clear()
        print("bye !")

    if n == 'h':
        clear()
        print(hlp)
        b = input("Tapez b pour revenir au menue principal:   ")
        if b == 'b':
            menue()

def menue():
    clear()
    print(header)
    main()

def nmap():
    print(headerNmap)
    ip = input("\nPlease Enter the IP adress: ")
    sc.scan(ip , '1-1023')
    print(sc.scaninfo())
    print(sc[ip]['tcp'].keys())

def vulnEx():
    print(headerVuln)
    ip = input("\nPlease Enter the IP adress: ")
    print(os.system('nmap -sV --script=vulscan.nse ' +ip))


##############################################################################################################################

#partie portant sur la cathegorie exploitation

def exploit():
    clear()
    print(headerExploit)
    e = input("1- Metasploit Framework\n2-Malware\n3-Install Tools\n\nChoice an option while typing a number :   ")

    if e == '1':
        clear()
        os.system('msfconsole')

    if e == '2':
        os.system('python3 malware.py')

    if e == '3':
        toolindev()

def toolindev():
    clear()
    indev = input("sorry this tool still in developement, press b to back:  ")

    if indev == 'b':
        menue()
    else:
        clear()
        print("Bad syntax, backing to main menue")
        sleep(1.00)
        main()



if __name__ == "__main__":
    main()